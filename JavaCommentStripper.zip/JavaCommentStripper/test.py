def main:
	print "This is a python script"
