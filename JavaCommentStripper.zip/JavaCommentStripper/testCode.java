/* Test Comment **/

public class testCode{
	public static void main(String[] args){
		// Normal Comment
		/* Block Comment */
		// Normal Comment 		with Tabs
		/* Block Comment that 
		is on multiple linez*/


		System.out.print("// Normal Comment within print, should not be hidden.");
		System.out.print("/*This is a block comment within a print statement, and should not be hidden*/");
		// comment with a \n /*block*/ within		
		/**
		 * Block Comment
		 * This line should also be hidden**/


		/*"This is a block comment"*/
		/* One star, then 1 star */
		/* One star, then 2 stars **/		
		/* One Star, then 3 stars ***/
		/* One Star, then 4 stars ****/
	}
}
